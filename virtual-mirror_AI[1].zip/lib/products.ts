// This would typically come from an API or database
export function getProducts(filters: any, searchQuery: string) {
  // Sample product data
  const allProducts = [
    {
      id: 1,
      name: "Floral Print Wrap Dress",
      brand: "Myntra Luxe",
      price: "₹1,299",
      originalPrice: "₹2,499",
      discount: 48,
      rating: 4.2,
      reviews: 128,
      image: "https://v0.blob.com/fashion-1.jpg",
      hoverImage: "https://v0.blob.com/fashion-1-hover.jpg",
      category: "dresses",
      bodyShapeMatch: "hourglass",
      sizes: ["s", "m", "l", "xl"],
    },
    {
      id: 2,
      name: "High-Waisted Slim Fit Jeans",
      brand: "Levis",
      price: "₹1,799",
      originalPrice: "₹2,999",
      discount: 40,
      rating: 4.5,
      reviews: 256,
      image: "https://v0.blob.com/fashion-2.jpg",
      hoverImage: "https://v0.blob.com/fashion-2-hover.jpg",
      category: "bottoms",
      bodyShapeMatch: "pear",
      sizes: ["xs", "s", "m", "l", "xl", "xxl"],
      isBestSeller: true,
    },
    {
      id: 3,
      name: "Peplum Top with Lace Detail",
      brand: "H&M",
      price: "₹899",
      originalPrice: "₹1,499",
      discount: 40,
      rating: 4.0,
      reviews: 89,
      image: "https://v0.blob.com/fashion-3.jpg",
      hoverImage: "https://v0.blob.com/fashion-3-hover.jpg",
      category: "tops",
      bodyShapeMatch: "apple",
      sizes: ["s", "m", "l"],
    },
    {
      id: 4,
      name: "A-Line Midi Skirt",
      brand: "Zara",
      price: "₹1,499",
      rating: 4.3,
      reviews: 112,
      image: "https://v0.blob.com/fashion-4.jpg",
      hoverImage: "https://v0.blob.com/fashion-4-hover.jpg",
      category: "bottoms",
      bodyShapeMatch: "pear",
      sizes: ["xs", "s", "m", "l"],
      isNew: true,
    },
    {
      id: 5,
      name: "V-Neck Blouse with Tie Detail",
      brand: "Forever 21",
      price: "₹799",
      originalPrice: "₹1,299",
      discount: 38,
      rating: 3.9,
      reviews: 76,
      image: "https://v0.blob.com/fashion-5.jpg",
      hoverImage: "https://v0.blob.com/fashion-5-hover.jpg",
      category: "tops",
      bodyShapeMatch: "inverted-triangle",
      sizes: ["xs", "s", "m", "l", "xl"],
    },
    {
      id: 6,
      name: "Straight Leg Trousers",
      brand: "H&M",
      price: "₹1,299",
      rating: 4.1,
      reviews: 94,
      image: "https://v0.blob.com/fashion-6.jpg",
      hoverImage: "https://v0.blob.com/fashion-6-hover.jpg",
      category: "bottoms",
      bodyShapeMatch: "rectangle",
      sizes: ["s", "m", "l", "xl"],
    },
    {
      id: 7,
      name: "Fit and Flare Dress",
      brand: "Myntra Luxe",
      price: "₹1,999",
      originalPrice: "₹3,499",
      discount: 43,
      rating: 4.6,
      reviews: 203,
      image: "https://v0.blob.com/fashion-7.jpg",
      hoverImage: "https://v0.blob.com/fashion-7-hover.jpg",
      category: "dresses",
      bodyShapeMatch: "pear",
      sizes: ["xs", "s", "m", "l"],
      isBestSeller: true,
    },
    {
      id: 8,
      name: "Oversized Boyfriend Shirt",
      brand: "Zara",
      price: "₹1,199",
      rating: 4.2,
      reviews: 87,
      image: "https://v0.blob.com/fashion-8.jpg",
      hoverImage: "https://v0.blob.com/fashion-8-hover.jpg",
      category: "tops",
      bodyShapeMatch: "apple",
      sizes: ["s", "m", "l", "xl"],
      isNew: true,
    },
    {
      id: 9,
      name: "Belted Sheath Dress",
      brand: "Forever 21",
      price: "₹1,599",
      originalPrice: "₹2,499",
      discount: 36,
      rating: 4.0,
      reviews: 65,
      image: "https://v0.blob.com/fashion-9.jpg",
      hoverImage: "https://v0.blob.com/fashion-9-hover.jpg",
      category: "dresses",
      bodyShapeMatch: "rectangle",
      sizes: ["xs", "s", "m", "l", "xl"],
    },
    {
      id: 10,
      name: "Wide Leg Palazzo Pants",
      brand: "Myntra Luxe",
      price: "₹1,399",
      rating: 4.4,
      reviews: 118,
      image: "https://v0.blob.com/fashion-10.jpg",
      hoverImage: "https://v0.blob.com/fashion-10-hover.jpg",
      category: "bottoms",
      bodyShapeMatch: "hourglass",
      sizes: ["s", "m", "l"],
    },
  ]

  // Apply filters
  let filteredProducts = [...allProducts]

  // Filter by search query
  if (searchQuery) {
    const query = searchQuery.toLowerCase()
    filteredProducts = filteredProducts.filter(
      (product) => product.name.toLowerCase().includes(query) || product.brand.toLowerCase().includes(query),
    )
  }

  // Filter by category
  if (filters.category && filters.category !== "all") {
    filteredProducts = filteredProducts.filter((product) => product.category === filters.category)
  }

  // Filter by price range
  if (filters.priceRange) {
    const [min, max] = filters.priceRange
    filteredProducts = filteredProducts.filter((product) => {
      const price = Number.parseInt(product.price.replace(/[^\d]/g, ""))
      return price >= min && price <= max
    })
  }

  // Filter by body shape
  if (filters.bodyShape) {
    filteredProducts = filteredProducts.filter((product) => product.bodyShapeMatch === filters.bodyShape)
  }

  // Filter by size
  if (filters.size) {
    filteredProducts = filteredProducts.filter((product) => product.sizes.includes(filters.size))
  }

  // Filter by brand
  if (filters.brand && filters.brand.length > 0) {
    filteredProducts = filteredProducts.filter((product) => filters.brand.includes(product.brand))
  }

  // Sort products
  if (filters.sort) {
    switch (filters.sort) {
      case "price-low-high":
        filteredProducts.sort((a, b) => {
          const priceA = Number.parseInt(a.price.replace(/[^\d]/g, ""))
          const priceB = Number.parseInt(b.price.replace(/[^\d]/g, ""))
          return priceA - priceB
        })
        break
      case "price-high-low":
        filteredProducts.sort((a, b) => {
          const priceA = Number.parseInt(a.price.replace(/[^\d]/g, ""))
          const priceB = Number.parseInt(b.price.replace(/[^\d]/g, ""))
          return priceB - priceA
        })
        break
      case "popularity":
        filteredProducts.sort((a, b) => b.reviews - a.reviews)
        break
      case "newest":
        // In a real app, you would sort by date
        filteredProducts.sort((a, b) => (a.isNew ? -1 : 1))
        break
      default:
        // Recommended - no specific sort
        break
    }
  }

  return filteredProducts
}

