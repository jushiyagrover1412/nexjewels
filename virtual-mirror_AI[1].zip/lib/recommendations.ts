// This would typically come from an API based on body shape and size
export function getRecommendations(type: string, bodyShape: string, size: string) {
  // Sample data - in a real app, this would be filtered based on the parameters
  const recommendations = {
    tops: [
      {
        id: 1,
        name: "V-Neck Blouse",
        brand: "Myntra Luxe",
        price: "₹899",
        originalPrice: "₹1,499",
        discount: 40,
        image: "https://v0.blob.com/recommendation-1.jpg",
        description: `Perfect for ${bodyShape} body types in size ${size.toUpperCase()}`,
      },
      {
        id: 2,
        name: "Wrap Top",
        brand: "H&M",
        price: "₹799",
        originalPrice: "₹1,299",
        discount: 38,
        image: "https://v0.blob.com/recommendation-2.jpg",
        description: `Flattering for ${bodyShape} body types in size ${size.toUpperCase()}`,
      },
      {
        id: 3,
        name: "Peplum Top",
        brand: "Zara",
        price: "₹1,099",
        image: "https://v0.blob.com/recommendation-3.jpg",
        description: `Enhances ${bodyShape} body types in size ${size.toUpperCase()}`,
      },
    ],
    bottoms: [
      {
        id: 4,
        name: "High-Waisted Jeans",
        brand: "Levis",
        price: "₹1,799",
        originalPrice: "₹2,999",
        discount: 40,
        image: "https://v0.blob.com/recommendation-4.jpg",
        description: `Great fit for ${bodyShape} body types in size ${size.toUpperCase()}`,
      },
      {
        id: 5,
        name: "A-Line Skirt",
        brand: "Forever 21",
        price: "₹1,299",
        image: "https://v0.blob.com/recommendation-5.jpg",
        description: `Complements ${bodyShape} body types in size ${size.toUpperCase()}`,
      },
      {
        id: 6,
        name: "Straight Leg Pants",
        brand: "H&M",
        price: "₹1,499",
        originalPrice: "₹1,999",
        discount: 25,
        image: "https://v0.blob.com/recommendation-6.jpg",
        description: `Balanced look for ${bodyShape} body types in size ${size.toUpperCase()}`,
      },
    ],
    dresses: [
      {
        id: 7,
        name: "Wrap Dress",
        brand: "Myntra Luxe",
        price: "₹1,999",
        originalPrice: "₹3,499",
        discount: 43,
        image: "https://v0.blob.com/recommendation-7.jpg",
        description: `Ideal for ${bodyShape} body types in size ${size.toUpperCase()}`,
      },
      {
        id: 8,
        name: "A-Line Dress",
        brand: "Zara",
        price: "₹1,699",
        image: "https://v0.blob.com/recommendation-8.jpg",
        description: `Flattering silhouette for ${bodyShape} body types in size ${size.toUpperCase()}`,
      },
      {
        id: 9,
        name: "Sheath Dress",
        brand: "Forever 21",
        price: "₹1,599",
        originalPrice: "₹2,499",
        discount: 36,
        image: "https://v0.blob.com/recommendation-9.jpg",
        description: `Elegant option for ${bodyShape} body types in size ${size.toUpperCase()}`,
      },
    ],
  }

  return recommendations[type as keyof typeof recommendations] || []
}

