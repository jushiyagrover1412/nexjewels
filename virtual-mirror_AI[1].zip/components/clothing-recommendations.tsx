"use client"

import { Heart, ShoppingBag, ExternalLink, Shirt } from "lucide-react"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { getRecommendations } from "@/lib/recommendations"

interface ClothingRecommendationsProps {
  type: string
  bodyShape: string
  size: string
  onTryOn?: (id: string) => void
}

export function ClothingRecommendations({ type, bodyShape, size, onTryOn }: ClothingRecommendationsProps) {
  const recommendations = getRecommendations(type, bodyShape, size)

  return (
    <div className="grid grid-cols-1 gap-4">
      {recommendations.map((item) => (
        <Card key={item.id} className="overflow-hidden border-0 shadow-md hover:shadow-lg transition-shadow">
          <div className="aspect-[4/3] relative bg-gradient-to-br from-pink-50 to-purple-50">
            <img src={item.image || "/placeholder.svg"} alt={item.name} className="object-contain w-full h-full p-2" />
            {item.discount && <Badge className="absolute top-2 left-2 bg-pink-600">{item.discount}% OFF</Badge>}
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-2 right-2 rounded-full bg-white/80 hover:bg-white"
            >
              <Heart className="h-4 w-4 text-pink-600" />
            </Button>
          </div>
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-medium">{item.name}</h3>
                <p className="text-sm text-gray-500 mt-1">{item.brand}</p>
                <p className="text-xs text-pink-600 mt-1">{item.description}</p>
              </div>
              <div className="text-right">
                <div className="font-bold">{item.price}</div>
                {item.originalPrice && <div className="text-sm text-gray-500 line-through">{item.originalPrice}</div>}
              </div>
            </div>
          </CardContent>
          <CardFooter className="p-4 pt-0 flex gap-2">
            {onTryOn && (
              <Button
                variant="outline"
                size="sm"
                className="flex-1 border-pink-200 hover:bg-pink-50 text-pink-600"
                onClick={() => onTryOn(item.id.toString())}
              >
                <Shirt className="h-4 w-4 mr-2" />
                Try On
              </Button>
            )}
            <Button variant="outline" size="sm" className="flex-1 border-pink-200 hover:bg-pink-50 text-pink-600">
              <Heart className="h-4 w-4 mr-2" />
              Wishlist
            </Button>
            <Button size="sm" className="flex-1 bg-pink-600 hover:bg-pink-700">
              <ShoppingBag className="h-4 w-4 mr-2" />
              Add to Bag
            </Button>
          </CardFooter>
        </Card>
      ))}
      <div className="mt-2">
        <Link href="/browse" className="text-sm text-pink-600 hover:text-pink-700 flex items-center">
          View all {type} <ExternalLink className="h-3 w-3 ml-1" />
        </Link>
      </div>
    </div>
  )
}

