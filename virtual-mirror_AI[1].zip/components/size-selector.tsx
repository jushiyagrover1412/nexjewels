"use client"

import { Circle } from "lucide-react"

import { cn } from "@/lib/utils"

const sizeCategories = [
  {
    id: "xs",
    name: "XS (Extra Small)",
    description: "US Size: 0-2",
  },
  {
    id: "s",
    name: "S (Small)",
    description: "US Size: 4-6",
  },
  {
    id: "m",
    name: "M (Medium)",
    description: "US Size: 8-10",
  },
  {
    id: "l",
    name: "L (Large)",
    description: "US Size: 12-14",
  },
  {
    id: "xl",
    name: "XL (Extra Large)",
    description: "US Size: 16-18",
  },
  {
    id: "xxl",
    name: "XXL (2X Large)",
    description: "US Size: 20-22",
  },
]

interface SizeSelectorProps {
  onSelect: (size: string) => void
  selected: string
}

export function SizeSelector({ onSelect, selected }: SizeSelectorProps) {
  return (
    <div className="space-y-3">
      {sizeCategories.map((size) => (
        <div
          key={size.id}
          className={cn(
            "flex items-center p-3 rounded-lg border cursor-pointer hover:bg-pink-50 transition-colors",
            selected === size.id ? "border-pink-500 bg-pink-50" : "border-gray-200",
          )}
          onClick={() => onSelect(size.id)}
        >
          <div className="flex-1">
            <h3 className="font-medium">{size.name}</h3>
            <p className="text-sm text-gray-500">{size.description}</p>
          </div>
          <div className="ml-2">
            <Circle className={cn("h-5 w-5", selected === size.id ? "text-pink-500 fill-pink-500" : "text-gray-300")} />
          </div>
        </div>
      ))}
    </div>
  )
}

