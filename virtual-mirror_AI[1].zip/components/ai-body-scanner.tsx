"use client"

import { useState, useRef, useEffect } from "react"
import * as tf from "@tensorflow/tfjs"
import * as poseDetection from "@tensorflow-models/pose-detection"
import { Camera, RefreshCw, ZoomIn, CheckCircle, AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { cn } from "@/lib/utils"

interface AIBodyScannerProps {
  onScanComplete: (bodyShape: string, measurements: BodyMeasurements) => void
  onCancel: () => void
}

export interface BodyMeasurements {
  size: string
  bust: number
  waist: number
  hips: number
  height: number
  shoulderWidth: number
}

// Body shape classifier thresholds based on measurements
const determineBodyShape = (measurements: BodyMeasurements): string => {
  const { bust, waist, hips, shoulderWidth } = measurements

  // Calculate ratios
  const shoulderToHip = shoulderWidth / hips
  const waistToHip = waist / hips
  const waistToBust = waist / bust

  // Rule-based classification
  if (shoulderToHip > 1.05 && waistToHip < 0.8) {
    return "inverted-triangle" // Shoulders wider than hips
  } else if (shoulderToHip < 0.95 && waistToHip > 0.75) {
    return "pear" // Hips wider than shoulders
  } else if (shoulderToHip > 0.95 && shoulderToHip < 1.05 && waistToBust < 0.75) {
    return "hourglass" // Balanced shoulders and hips with defined waist
  } else if (waistToBust > 0.85 && waistToHip > 0.85) {
    return "apple" // Fuller midsection
  } else {
    return "rectangle" // Straight figure
  }
}

// Calculate size based on measurements
const determineSize = (measurements: BodyMeasurements): string => {
  const { bust, waist, hips } = measurements

  // Take the largest measurement for size determination
  const maxMeasurement = Math.max(bust, waist, hips)

  // Size chart (in cm)
  if (maxMeasurement < 83) {
    return "xs"
  } else if (maxMeasurement < 88) {
    return "s"
  } else if (maxMeasurement < 93) {
    return "m"
  } else if (maxMeasurement < 100) {
    return "l"
  } else if (maxMeasurement < 107) {
    return "xl"
  } else {
    return "xxl"
  }
}

export function AIBodyScanner({ onScanComplete, onCancel }: AIBodyScannerProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [detector, setDetector] = useState<poseDetection.PoseDetector | null>(null)
  const [cameraPermission, setCameraPermission] = useState<"prompt" | "granted" | "denied">("prompt")
  const [isScanning, setIsScanning] = useState(false)
  const [scanProgress, setScanProgress] = useState(0)
  const [scanComplete, setScanComplete] = useState(false)
  const [scanResult, setScanResult] = useState<string>("")
  const [cameraError, setCameraError] = useState<string | null>(null)
  const [modelLoading, setModelLoading] = useState(true)
  const [measurements, setMeasurements] = useState<BodyMeasurements | null>(null)
  const [poseDetected, setPoseDetected] = useState(false)
  const [poseSamples, setPoseSamples] = useState<poseDetection.Pose[]>([])
  const rafId = useRef<number | null>(null)

  // Initialize TensorFlow and load pose detection model
  useEffect(() => {
    async function setupTensorFlow() {
      try {
        await tf.ready()

        // Load MoveNet model (lighter than PoseNet)
        const detectorConfig = {
          modelType: poseDetection.movenet.modelType.SINGLEPOSE_LIGHTNING,
          enableSmoothing: true,
        }
        const detector = await poseDetection.createDetector(poseDetection.SupportedModels.MoveNet, detectorConfig)

        setDetector(detector)
        setModelLoading(false)
      } catch (error) {
        console.error("Error initializing TensorFlow:", error)
        setCameraError("Failed to load AI model. Please try again later.")
      }
    }

    setupTensorFlow()

    return () => {
      if (rafId.current) {
        cancelAnimationFrame(rafId.current)
      }
    }
  }, [])

  // Initialize camera
  useEffect(() => {
    const initCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: "user",
            width: { ideal: 1280 },
            height: { ideal: 720 },
          },
        })

        if (videoRef.current) {
          videoRef.current.srcObject = stream
          setCameraPermission("granted")
        }
      } catch (err) {
        console.error("Error accessing camera:", err)
        setCameraPermission("denied")
        setCameraError("Camera access denied. Please allow camera access to use the scanner.")
      }
    }

    if (!modelLoading) {
      initCamera()
    }

    // Cleanup function to stop camera when component unmounts
    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        const tracks = (videoRef.current.srcObject as MediaStream).getTracks()
        tracks.forEach((track) => track.stop())
      }
    }
  }, [modelLoading])

  // Detect pose and draw skeleton on canvas
  const detectPose = async () => {
    if (!detector || !videoRef.current || !canvasRef.current) return

    if (videoRef.current.readyState < 2) {
      rafId.current = requestAnimationFrame(detectPose)
      return
    }

    // Get pose
    const video = videoRef.current
    const poses = await detector.estimatePoses(video)

    if (poses.length > 0) {
      setPoseDetected(true)

      // If actively scanning, collect pose data
      if (isScanning && !scanComplete) {
        setPoseSamples((prev) => [...prev, poses[0]])
      }

      // Draw result on canvas
      const ctx = canvasRef.current.getContext("2d")
      if (ctx) {
        const videoWidth = video.videoWidth
        const videoHeight = video.videoHeight

        canvasRef.current.width = videoWidth
        canvasRef.current.height = videoHeight

        // Clear canvas
        ctx.clearRect(0, 0, videoWidth, videoHeight)

        // Draw skeleton
        if (poses.length > 0) {
          drawSkeleton(poses[0], ctx, videoWidth, videoHeight)
        }
      }
    } else {
      setPoseDetected(false)
    }

    if (isScanning && !scanComplete) {
      rafId.current = requestAnimationFrame(detectPose)
    }
  }

  // Draw skeleton on canvas
  const drawSkeleton = (pose: poseDetection.Pose, ctx: CanvasRenderingContext2D, width: number, height: number) => {
    const keypoints = pose.keypoints

    // Draw points
    for (let i = 0; i < keypoints.length; i++) {
      const keypoint = keypoints[i]

      if (keypoint.score && keypoint.score > 0.3) {
        ctx.beginPath()
        ctx.arc(keypoint.x, keypoint.y, 5, 0, 2 * Math.PI)
        ctx.fillStyle = "#FF69B4"
        ctx.fill()
      }
    }

    // Define the connections
    const connections = [
      ["nose", "left_eye"],
      ["nose", "right_eye"],
      ["left_eye", "left_ear"],
      ["right_eye", "right_ear"],
      ["left_shoulder", "right_shoulder"],
      ["left_shoulder", "left_elbow"],
      ["right_shoulder", "right_elbow"],
      ["left_elbow", "left_wrist"],
      ["right_elbow", "right_wrist"],
      ["left_shoulder", "left_hip"],
      ["right_shoulder", "right_hip"],
      ["left_hip", "right_hip"],
      ["left_hip", "left_knee"],
      ["right_hip", "right_knee"],
      ["left_knee", "left_ankle"],
      ["right_knee", "right_ankle"],
    ]

    // Draw lines
    ctx.strokeStyle = "#FF69B4"
    ctx.lineWidth = 2

    for (const [from, to] of connections) {
      const fromPoint = keypoints.find((kp) => kp.name === from)
      const toPoint = keypoints.find((kp) => kp.name === to)

      if (fromPoint && toPoint && fromPoint.score && toPoint.score && fromPoint.score > 0.3 && toPoint.score > 0.3) {
        ctx.beginPath()
        ctx.moveTo(fromPoint.x, fromPoint.y)
        ctx.lineTo(toPoint.x, toPoint.y)
        ctx.stroke()
      }
    }
  }

  // Start real-time pose detection
  useEffect(() => {
    if (cameraPermission === "granted" && !modelLoading && detector) {
      rafId.current = requestAnimationFrame(detectPose)
    }

    return () => {
      if (rafId.current) {
        cancelAnimationFrame(rafId.current)
        rafId.current = null
      }
    }
  }, [cameraPermission, detector, modelLoading])

  const startScan = () => {
    setIsScanning(true)
    setScanProgress(0)
    setPoseSamples([])

    // Start continuous pose detection
    if (rafId.current) {
      cancelAnimationFrame(rafId.current)
    }
    rafId.current = requestAnimationFrame(detectPose)

    // Simulate scanning progress
    const interval = setInterval(() => {
      setScanProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          completeScan()
          return 100
        }
        return prev + 2
      })
    }, 100)
  }

  const completeScan = () => {
    // Stop continuous detection
    if (rafId.current) {
      cancelAnimationFrame(rafId.current)
      rafId.current = null
    }

    // Calculate body measurements from collected pose samples
    if (poseSamples.length > 0) {
      const calculatedMeasurements = calculateBodyMeasurements(poseSamples)
      const shape = determineBodyShape(calculatedMeasurements)

      setMeasurements(calculatedMeasurements)
      setScanResult(shape)
      setScanComplete(true)

      // Wait 2 seconds before returning the result
      setTimeout(() => {
        onScanComplete(shape, calculatedMeasurements)
      }, 2000)
    } else {
      setCameraError("No body detected. Please try again in better lighting.")
      setIsScanning(false)
    }
  }

  // Calculate body measurements from pose keypoints
  const calculateBodyMeasurements = (poses: poseDetection.Pose[]): BodyMeasurements => {
    // Average the samples to reduce noise
    const avgPose = averagePoseSamples(poses)

    // Extract relevant keypoints
    const leftShoulder = avgPose.find((kp) => kp.name === "left_shoulder")
    const rightShoulder = avgPose.find((kp) => kp.name === "right_shoulder")
    const leftHip = avgPose.find((kp) => kp.name === "left_hip")
    const rightHip = avgPose.find((kp) => kp.name === "right_hip")
    const leftAnkle = avgPose.find((kp) => kp.name === "left_ankle")
    const rightAnkle = avgPose.find((kp) => kp.name === "right_ankle")

    // Calculate measurements (in relative pixel space)
    // Note: In a real app, you would calibrate to real-world units
    const shoulderWidth = rightShoulder && leftShoulder ? Math.abs(rightShoulder.x - leftShoulder.x) : 0

    const hipWidth = rightHip && leftHip ? Math.abs(rightHip.x - leftHip.x) : 0

    // Estimate bust as slightly above midpoint of shoulder to hip
    const bustHeight = leftShoulder && leftHip ? leftShoulder.y + (leftHip.y - leftShoulder.y) * 0.3 : 0

    // Estimate bust width as slightly wider than shoulders
    const bustWidth = shoulderWidth * 1.05

    // Estimate waist at midpoint of shoulder to hip
    const waistHeight = leftShoulder && leftHip ? leftShoulder.y + (leftHip.y - leftShoulder.y) * 0.5 : 0

    // Estimate waist width as narrower than hips
    const waistWidth = hipWidth * 0.85

    // Calculate body height
    const height = leftShoulder && leftAnkle ? Math.abs(leftAnkle.y - leftShoulder.y) * 1.3 : 0 // Add 30% for head

    // Convert to measurements - these are relative values
    // In a real app, you would use a calibration object or known reference
    const bust = bustWidth
    const waist = waistWidth
    const hips = hipWidth

    // Determine clothing size
    const size = determineSize({
      size: "", // Will be filled by determineSize
      bust,
      waist,
      hips,
      height,
      shoulderWidth,
    })

    return {
      size,
      bust,
      waist,
      hips,
      height,
      shoulderWidth,
    }
  }

  // Average multiple pose samples to improve accuracy
  const averagePoseSamples = (poses: poseDetection.Pose[]): poseDetection.Keypoint[] => {
    const keypoints: { [key: string]: { x: number; y: number; count: number } } = {}

    // Collect all keypoints
    for (const pose of poses) {
      for (const keypoint of pose.keypoints) {
        if (keypoint.score && keypoint.score > 0.3) {
          if (!keypoints[keypoint.name!]) {
            keypoints[keypoint.name!] = { x: 0, y: 0, count: 0 }
          }

          keypoints[keypoint.name!].x += keypoint.x
          keypoints[keypoint.name!].y += keypoint.y
          keypoints[keypoint.name!].count += 1
        }
      }
    }

    // Calculate averages
    return Object.entries(keypoints).map(([name, data]) => ({
      name,
      x: data.x / data.count,
      y: data.y / data.count,
      score: 1.0, // High confidence for averaged result
    }))
  }

  const retakeScan = () => {
    setIsScanning(false)
    setScanComplete(false)
    setScanProgress(0)
    setScanResult("")
    setMeasurements(null)
    setPoseSamples([])
    if (rafId.current) {
      cancelAnimationFrame(rafId.current)
    }
    rafId.current = requestAnimationFrame(detectPose)
  }

  if (modelLoading) {
    return (
      <div className="p-8 text-center bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
        <RefreshCw className="w-16 h-16 mx-auto mb-4 text-pink-500 animate-spin" />
        <h3 className="text-xl font-bold mb-2 text-white">Loading AI Model</h3>
        <p className="text-gray-300 mb-6">Please wait while we initialize the body detection model...</p>
        <Progress value={45} className="h-2 w-64 mx-auto bg-gray-700" />
      </div>
    )
  }

  if (cameraPermission === "denied") {
    return (
      <div className="p-8 text-center bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
        <Camera className="w-16 h-16 mx-auto mb-4 text-red-500" />
        <h3 className="text-xl font-bold mb-2 text-white">Camera Access Required</h3>
        <p className="text-gray-300 mb-6">{cameraError || "Please allow camera access to use the body scanner."}</p>
        <Button onClick={onCancel} variant="outline" className="border-white/20 text-white hover:bg-white/10">
          Go Back
        </Button>
      </div>
    )
  }

  return (
    <div className="relative overflow-hidden rounded-xl bg-black/30 backdrop-blur-sm border border-white/20">
      <div className="aspect-[3/4] relative">
        {/* Video element */}
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className={cn("absolute inset-0 w-full h-full object-cover", isScanning ? "opacity-70" : "opacity-90")}
        />

        {/* Canvas overlay for skeleton */}
        <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />

        {/* Position guide overlay */}
        {!isScanning && !scanComplete && !poseDetected && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/30 backdrop-blur-sm">
            <div className="p-6 bg-black/60 rounded-xl text-center">
              <AlertTriangle className="w-12 h-12 mx-auto mb-4 text-yellow-500" />
              <h3 className="text-xl font-bold mb-2 text-white">Position Yourself</h3>
              <p className="text-gray-300 mb-4">Please stand back so your full body is visible in the frame.</p>
            </div>
          </div>
        )}

        {/* Position guide overlay with person detected */}
        {!isScanning && !scanComplete && poseDetected && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/20 backdrop-blur-sm">
            <div className="p-6 bg-black/60 rounded-xl text-center">
              <CheckCircle className="w-12 h-12 mx-auto mb-4 text-green-500" />
              <h3 className="text-xl font-bold mb-2 text-white">Perfect!</h3>
              <p className="text-gray-300 mb-4">Your body is detected. Press "Start Scan" when ready.</p>
            </div>
          </div>
        )}

        {/* Scanning overlay */}
        {isScanning && !scanComplete && (
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <div className="relative w-64 h-64 mb-8">
              {/* Scanning animation */}
              <div className="absolute inset-0 border-2 border-pink-500 rounded-md"></div>
              <div className="absolute inset-0 flex items-center">
                <div className="w-full h-1 bg-gradient-to-r from-transparent via-pink-500 to-transparent animate-scan"></div>
              </div>
              <div className="absolute -top-2 -left-2 w-4 h-4 border-t-2 border-l-2 border-pink-500"></div>
              <div className="absolute -top-2 -right-2 w-4 h-4 border-t-2 border-r-2 border-pink-500"></div>
              <div className="absolute -bottom-2 -left-2 w-4 h-4 border-b-2 border-l-2 border-pink-500"></div>
              <div className="absolute -bottom-2 -right-2 w-4 h-4 border-b-2 border-r-2 border-pink-500"></div>
            </div>
            <div className="text-center text-white">
              <h3 className="text-xl font-bold mb-2">Analyzing Body Shape</h3>
              <p className="text-gray-300 mb-4">Please stand still...</p>
              <Progress value={scanProgress} className="h-2 w-64 bg-gray-700" />
              <p className="mt-2 text-sm text-gray-300">{scanProgress}% Complete</p>
            </div>
          </div>
        )}

        {/* Scan result overlay */}
        {scanComplete && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/50 backdrop-blur-sm">
            <div className="bg-white/90 p-6 rounded-xl max-w-xs text-center">
              <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                <ZoomIn className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold mb-2">Analysis Complete!</h3>
              <p className="mb-4">We've identified your body profile:</p>
              <div className="bg-purple-100 p-3 rounded-lg mb-4">
                <p className="font-bold text-lg capitalize">{scanResult.replace("-", " ")}</p>
                <p className="text-sm">Size: {measurements?.size.toUpperCase()}</p>
              </div>
              <div className="grid grid-cols-2 gap-2 mb-4 text-sm">
                <div className="bg-gray-100 p-2 rounded">
                  <p className="font-semibold">Bust/Chest</p>
                  <p>{Math.round(measurements?.bust || 0)}cm</p>
                </div>
                <div className="bg-gray-100 p-2 rounded">
                  <p className="font-semibold">Waist</p>
                  <p>{Math.round(measurements?.waist || 0)}cm</p>
                </div>
                <div className="bg-gray-100 p-2 rounded">
                  <p className="font-semibold">Hips</p>
                  <p>{Math.round(measurements?.hips || 0)}cm</p>
                </div>
                <div className="bg-gray-100 p-2 rounded">
                  <p className="font-semibold">Height</p>
                  <p>{Math.round((measurements?.height || 0) / 10)}cm</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Controls overlay */}
        <div className="absolute bottom-0 inset-x-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
          <div className="flex justify-between items-center">
            {!isScanning ? (
              <>
                <Button variant="outline" onClick={onCancel} className="border-white/20 text-white hover:bg-white/10">
                  Cancel
                </Button>
                <Button
                  onClick={startScan}
                  className="bg-pink-600 hover:bg-pink-700 text-white"
                  disabled={!poseDetected || modelLoading}
                >
                  <Camera className="mr-2 h-4 w-4" />
                  {poseDetected ? "Start Scan" : "Position Yourself"}
                </Button>
              </>
            ) : !scanComplete ? (
              <>
                <Button variant="outline" onClick={retakeScan} className="border-white/20 text-white hover:bg-white/10">
                  Cancel Scan
                </Button>
                <div className="flex items-center text-white text-sm">
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Scanning...
                </div>
              </>
            ) : (
              <>
                <Button variant="outline" onClick={retakeScan} className="border-white/20 text-white hover:bg-white/10">
                  Scan Again
                </Button>
                <Button
                  onClick={() => measurements && onScanComplete(scanResult, measurements)}
                  className="bg-pink-600 hover:bg-pink-700 text-white"
                >
                  Continue
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

