"use client"

import Image from "next/image"
import { Circle } from "lucide-react"

import { cn } from "@/lib/utils"

const bodyShapes = [
  {
    id: "hourglass",
    name: "Hourglass",
    description: "Balanced shoulders and hips with a defined waist",
    icon: "https://v0.blob.com/hourglass-shape.svg",
  },
  {
    id: "pear",
    name: "Pear",
    description: "Narrower shoulders and wider hips",
    icon: "https://v0.blob.com/pear-shape.svg",
  },
  {
    id: "apple",
    name: "Apple",
    description: "Fuller midsection with slimmer legs",
    icon: "https://v0.blob.com/apple-shape.svg",
  },
  {
    id: "rectangle",
    name: "Rectangle",
    description: "Straight figure with minimal waist definition",
    icon: "https://v0.blob.com/rectangle-shape.svg",
  },
]

interface BodyShapeSelectorProps {
  onSelect: (shape: string) => void
  selected: string
}

export function BodyShapeSelector({ onSelect, selected }: BodyShapeSelectorProps) {
  return (
    <div className="space-y-2">
      {bodyShapes.map((shape) => (
        <div
          key={shape.id}
          className={cn(
            "flex items-center p-4 rounded-lg border border-gray-200 bg-white/10 backdrop-blur-sm cursor-pointer hover:bg-white/20 transition-colors",
            selected === shape.id && "border-pink-500 bg-white/20",
          )}
          onClick={() => onSelect(shape.id)}
        >
          <div className="flex-shrink-0 mr-4 h-16 w-16 rounded-lg overflow-hidden bg-white/10">
            <Image
              src={shape.icon || "/placeholder.svg"}
              alt={shape.name}
              width={64}
              height={64}
              className="h-full w-full object-contain p-2"
            />
          </div>
          <div className="flex-1">
            <h3 className="font-medium text-white">{shape.name}</h3>
            <p className="text-sm text-gray-300">{shape.description}</p>
          </div>
          <Circle
            className={cn("h-5 w-5 ml-2", selected === shape.id ? "text-pink-500 fill-pink-500" : "text-gray-400")}
          />
        </div>
      ))}
    </div>
  )
}

