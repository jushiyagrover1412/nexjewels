"use client"

import { useState, useRef, useEffect } from "react"
import { Camera, RefreshCw, ZoomIn } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"

interface BodyScannerProps {
  onScanComplete: (bodyShape: string) => void
  onCancel: () => void
}

export function BodyScanner({ onScanComplete, onCancel }: BodyScannerProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [cameraPermission, setCameraPermission] = useState<"prompt" | "granted" | "denied">("prompt")
  const [isScanning, setIsScanning] = useState(false)
  const [scanProgress, setScanProgress] = useState(0)
  const [scanComplete, setScanComplete] = useState(false)
  const [scanResult, setScanResult] = useState<string>("")
  const [cameraError, setCameraError] = useState<string | null>(null)

  // Initialize camera
  useEffect(() => {
    const initCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: "user",
            width: { ideal: 1280 },
            height: { ideal: 720 },
          },
        })

        if (videoRef.current) {
          videoRef.current.srcObject = stream
          setCameraPermission("granted")
        }
      } catch (err) {
        console.error("Error accessing camera:", err)
        setCameraPermission("denied")
        setCameraError("Camera access denied. Please allow camera access to use the scanner.")
      }
    }

    initCamera()

    // Cleanup function to stop camera when component unmounts
    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        const tracks = (videoRef.current.srcObject as MediaStream).getTracks()
        tracks.forEach((track) => track.stop())
      }
    }
  }, [])

  const startScan = () => {
    setIsScanning(true)
    setScanProgress(0)

    // Simulate scanning process
    const interval = setInterval(() => {
      setScanProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          completeScan()
          return 100
        }
        return prev + 2
      })
    }, 100)
  }

  const completeScan = () => {
    // Capture current frame from video
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current
      const canvas = canvasRef.current
      const context = canvas.getContext("2d")

      if (context) {
        canvas.width = video.videoWidth
        canvas.height = video.videoHeight
        context.drawImage(video, 0, 0, canvas.width, canvas.height)

        // In a real app, we would analyze the image here
        // For this demo, we'll randomly select a body shape
        const bodyShapes = ["hourglass", "pear", "apple", "rectangle"]
        const randomShape = bodyShapes[Math.floor(Math.random() * bodyShapes.length)]

        setScanResult(randomShape)
        setScanComplete(true)

        // Wait 2 seconds before returning the result
        setTimeout(() => {
          onScanComplete(randomShape)
        }, 2000)
      }
    }
  }

  const retakeScan = () => {
    setIsScanning(false)
    setScanComplete(false)
    setScanProgress(0)
    setScanResult("")
  }

  if (cameraPermission === "denied") {
    return (
      <div className="p-8 text-center bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
        <Camera className="w-16 h-16 mx-auto mb-4 text-red-500" />
        <h3 className="text-xl font-bold mb-2 text-white">Camera Access Required</h3>
        <p className="text-gray-300 mb-6">{cameraError || "Please allow camera access to use the body scanner."}</p>
        <Button onClick={onCancel} variant="outline" className="border-white/20 text-white hover:bg-white/10">
          Go Back
        </Button>
      </div>
    )
  }

  return (
    <div className="relative overflow-hidden rounded-xl bg-black/30 backdrop-blur-sm border border-white/20">
      <div className="aspect-[3/4] relative">
        {/* Hidden canvas for image capture */}
        <canvas ref={canvasRef} className="hidden" />

        {/* Video feed */}
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className={`w-full h-full object-cover ${isScanning ? "opacity-90" : "opacity-100"}`}
        />

        {/* Scanning overlay */}
        {isScanning && !scanComplete && (
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <div className="relative w-64 h-64 mb-8">
              {/* Scanning animation */}
              <div className="absolute inset-0 border-2 border-pink-500 rounded-md"></div>
              <div className="absolute inset-0 flex items-center">
                <div className="w-full h-1 bg-gradient-to-r from-transparent via-pink-500 to-transparent animate-scan"></div>
              </div>
              <div className="absolute -top-2 -left-2 w-4 h-4 border-t-2 border-l-2 border-pink-500"></div>
              <div className="absolute -top-2 -right-2 w-4 h-4 border-t-2 border-r-2 border-pink-500"></div>
              <div className="absolute -bottom-2 -left-2 w-4 h-4 border-b-2 border-l-2 border-pink-500"></div>
              <div className="absolute -bottom-2 -right-2 w-4 h-4 border-b-2 border-r-2 border-pink-500"></div>
            </div>
            <div className="text-center text-white">
              <h3 className="text-xl font-bold mb-2">Scanning Body Shape</h3>
              <p className="text-gray-300 mb-4">Please stand still...</p>
              <Progress value={scanProgress} className="h-2 w-64 bg-gray-700" />
              <p className="mt-2 text-sm text-gray-300">{scanProgress}% Complete</p>
            </div>
          </div>
        )}

        {/* Scan result overlay */}
        {scanComplete && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/50 backdrop-blur-sm">
            <div className="bg-white/90 p-6 rounded-xl max-w-xs text-center">
              <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                <ZoomIn className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold mb-2">Scan Complete!</h3>
              <p className="mb-4">We've detected your body shape:</p>
              <div className="bg-purple-100 p-3 rounded-lg mb-4">
                <p className="font-bold text-lg capitalize">{scanResult.replace("-", " ")}</p>
              </div>
              <p className="text-sm text-gray-600 mb-4">
                Our AI has analyzed your proportions and determined this is your best match.
              </p>
            </div>
          </div>
        )}

        {/* Controls overlay */}
        <div className="absolute bottom-0 inset-x-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
          <div className="flex justify-between items-center">
            {!isScanning ? (
              <>
                <Button variant="outline" onClick={onCancel} className="border-white/20 text-white hover:bg-white/10">
                  Cancel
                </Button>
                <Button onClick={startScan} className="bg-pink-600 hover:bg-pink-700 text-white">
                  <Camera className="mr-2 h-4 w-4" />
                  Start Scan
                </Button>
              </>
            ) : !scanComplete ? (
              <>
                <Button variant="outline" onClick={retakeScan} className="border-white/20 text-white hover:bg-white/10">
                  Cancel Scan
                </Button>
                <div className="flex items-center text-white text-sm">
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Scanning...
                </div>
              </>
            ) : (
              <>
                <Button variant="outline" onClick={retakeScan} className="border-white/20 text-white hover:bg-white/10">
                  Scan Again
                </Button>
                <Button onClick={() => onScanComplete(scanResult)} className="bg-pink-600 hover:bg-pink-700 text-white">
                  Continue
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

