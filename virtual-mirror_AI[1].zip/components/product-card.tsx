"use client"

import { useState } from "react"
import Image from "next/image"
import { Heart, ShoppingBag, Star } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

interface ProductCardProps {
  product: {
    id: number
    name: string
    brand: string
    price: string
    originalPrice?: string
    discount?: number
    rating: number
    reviews: number
    image: string
    hoverImage?: string
    isNew?: boolean
    isBestSeller?: boolean
    bodyShapeMatch?: string
  }
}

export function ProductCard({ product }: ProductCardProps) {
  const [isHovered, setIsHovered] = useState(false)
  const [isWishlisted, setIsWishlisted] = useState(false)

  return (
    <div className="group relative" onMouseEnter={() => setIsHovered(true)} onMouseLeave={() => setIsHovered(false)}>
      <div className="aspect-[3/4] relative overflow-hidden rounded-lg bg-gray-100">
        <Image
          src={isHovered && product.hoverImage ? product.hoverImage : product.image}
          alt={product.name}
          fill
          className="object-cover transition-all duration-300 group-hover:scale-105"
        />

        {product.discount && <Badge className="absolute top-2 left-2 bg-pink-600">{product.discount}% OFF</Badge>}

        {product.isNew && <Badge className="absolute top-2 left-2 bg-blue-600">NEW</Badge>}

        {product.isBestSeller && <Badge className="absolute top-2 left-2 bg-amber-600">BESTSELLER</Badge>}

        <Button
          variant="ghost"
          size="icon"
          className={cn(
            "absolute top-2 right-2 rounded-full bg-white/80 hover:bg-white",
            isWishlisted && "text-pink-600 fill-pink-600",
          )}
          onClick={(e) => {
            e.preventDefault()
            setIsWishlisted(!isWishlisted)
          }}
        >
          <Heart className={cn("h-4 w-4", isWishlisted && "fill-pink-600")} />
        </Button>

        <div className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center pb-2">
          <Button size="sm" className="bg-white text-black hover:bg-gray-100">
            <ShoppingBag className="h-4 w-4 mr-2" />
            Add to Bag
          </Button>
        </div>
      </div>

      <div className="mt-3">
        <div className="flex items-center justify-between">
          <h3 className="font-medium text-sm truncate">{product.name}</h3>
        </div>
        <p className="text-xs text-gray-500 mt-1">{product.brand}</p>

        <div className="flex items-center justify-between mt-1">
          <div className="flex items-center">
            <div className="font-semibold text-sm">{product.price}</div>
            {product.originalPrice && (
              <div className="text-xs text-gray-500 line-through ml-2">{product.originalPrice}</div>
            )}
          </div>

          <div className="flex items-center">
            <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
            <span className="text-xs ml-1">{product.rating}</span>
          </div>
        </div>

        {product.bodyShapeMatch && (
          <p className="text-xs text-pink-600 mt-1">Perfect for {product.bodyShapeMatch} body shape</p>
        )}
      </div>
    </div>
  )
}

