"use client"

import { useState, useRef, useEffect } from "react"
import { ArrowLeft, Download, Camera, RotateCcw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { cn } from "@/lib/utils"
import type { BodyMeasurements } from "./ai-body-scanner"
import { getClothingItem } from "@/lib/clothing-items"

interface VirtualTryOnProps {
  clothingId: string
  bodyShape: string
  measurements: BodyMeasurements | null
  onExit: () => void
}

export function VirtualTryOn({ clothingId, bodyShape, measurements, onExit }: VirtualTryOnProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [cameraActive, setCameraActive] = useState(false)
  const [usingSilhouette, setUsingSilhouette] = useState(true)
  const [clothingFit, setClothingFit] = useState(50)
  const [clothingPosition, setClothingPosition] = useState(50)
  const [clothingSize, setClothingSize] = useState(100)
  const [rotation, setRotation] = useState(0)
  const [hasSnapshot, setHasSnapshot] = useState(false)
  const [clothingItem, setClothingItem] = useState<any>(null)
  const [clothingImage, setClothingImage] = useState<HTMLImageElement | null>(null)
  const [size, setSize] = useState<string | undefined>(clothingItem?.size)

  // Load clothing item data
  useEffect(() => {
    if (clothingId) {
      const item = getClothingItem(clothingId)
      setClothingItem(item)
      setSize(item?.size)

      // Load clothing image
      const img = new Image()
      img.crossOrigin = "anonymous"
      img.src = item?.tryOnImage || item?.image || "/placeholder.svg"
      img.onload = () => {
        setClothingImage(img)
      }
    }
  }, [clothingId])

  // Initialize camera if needed
  useEffect(() => {
    if (!cameraActive) return

    const initCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: "user",
            width: { ideal: 1280 },
            height: { ideal: 720 },
          },
        })

        if (videoRef.current) {
          videoRef.current.srcObject = stream
        }
      } catch (err) {
        console.error("Error accessing camera:", err)
        setCameraActive(false)
      }
    }

    initCamera()

    // Cleanup
    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        const tracks = (videoRef.current.srcObject as MediaStream).getTracks()
        tracks.forEach((track) => track.stop())
      }
    }
  }, [cameraActive])

  // Draw on canvas
  useEffect(() => {
    if (!canvasRef.current || !clothingImage) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    if (hasSnapshot) {
      // If we have a snapshot, we don't need to redraw the background
      return
    }

    // Draw silhouette or video
    if (usingSilhouette) {
      // Draw silhouette based on body shape
      drawSilhouette(ctx, canvas.width, canvas.height, bodyShape)

      // Overlay clothing
      drawClothing(ctx, clothingImage, canvas.width, canvas.height)
    } else if (cameraActive && videoRef.current) {
      // Draw video frame
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height)

      // Overlay clothing
      drawClothing(ctx, clothingImage, canvas.width, canvas.height)
    }
  }, [
    bodyShape,
    clothingImage,
    clothingFit,
    clothingPosition,
    clothingSize,
    rotation,
    usingSilhouette,
    cameraActive,
    hasSnapshot,
  ])

  // Draw silhouette based on body shape
  const drawSilhouette = (ctx: CanvasRenderingContext2D, width: number, height: number, shape: string) => {
    // Set background
    ctx.fillStyle = "#f9f9f9"
    ctx.fillRect(0, 0, width, height)

    // Draw body silhouette based on shape
    const centerX = width / 2
    const headSize = height * 0.12
    const shoulderY = headSize * 2
    const hipY = height * 0.55
    const kneeY = height * 0.75
    const footY = height * 0.95

    // Different proportions based on body shape
    let shoulderWidth, waistWidth, hipWidth

    switch (shape) {
      case "hourglass":
        shoulderWidth = width * 0.25
        waistWidth = width * 0.15
        hipWidth = width * 0.25
        break
      case "pear":
        shoulderWidth = width * 0.2
        waistWidth = width * 0.17
        hipWidth = width * 0.28
        break
      case "apple":
        shoulderWidth = width * 0.25
        waistWidth = width * 0.24
        hipWidth = width * 0.22
        break
      case "inverted-triangle":
        shoulderWidth = width * 0.28
        waistWidth = width * 0.18
        hipWidth = width * 0.2
        break
      case "rectangle":
      default:
        shoulderWidth = width * 0.22
        waistWidth = width * 0.19
        hipWidth = width * 0.22
        break
    }

    ctx.fillStyle = "#ddd"

    // Draw head (simple circle)
    ctx.beginPath()
    ctx.arc(centerX, headSize, headSize, 0, Math.PI * 2)
    ctx.fill()

    // Draw body (simplified shape)
    ctx.beginPath()
    ctx.moveTo(centerX - shoulderWidth, shoulderY) // Left shoulder
    ctx.lineTo(centerX - waistWidth, hipY - height * 0.15) // Left waist
    ctx.lineTo(centerX - hipWidth, hipY) // Left hip
    ctx.lineTo(centerX - width * 0.08, footY) // Left foot
    ctx.lineTo(centerX + width * 0.08, footY) // Right foot
    ctx.lineTo(centerX + hipWidth, hipY) // Right hip
    ctx.lineTo(centerX + waistWidth, hipY - height * 0.15) // Right waist
    ctx.lineTo(centerX + shoulderWidth, shoulderY) // Right shoulder
    ctx.closePath()
    ctx.fill()
  }

  // Draw clothing overlay
  const drawClothing = (
    ctx: CanvasRenderingContext2D,
    clothingImg: HTMLImageElement,
    width: number,
    height: number,
  ) => {
    if (!clothingImg) return

    // Apply transformation for clothing
    ctx.save()

    const centerX = width / 2
    const centerY = height * 0.35 // Position near chest/upper body

    // Adjust position based on slider value (convert 0-100 range to actual pixels)
    const verticalOffset = ((clothingPosition - 50) / 50) * height * 0.2

    // Position at center, then apply transformations
    ctx.translate(centerX, centerY + verticalOffset)

    // Apply rotation (convert 0-100 to degrees)
    const rotationDegrees = ((rotation - 50) / 50) * 20 // +/- 20 degrees
    ctx.rotate((rotationDegrees * Math.PI) / 180)

    // Scale based on fit and size
    const baseScale = (width / clothingImg.width) * 0.5 // Base scaling factor
    const fitScale = (clothingFit / 100) * 0.5 + 0.75 // Convert 0-100 to 0.75-1.25 range
    const sizeScale = (clothingSize / 100) * 0.5 + 0.75 // Convert 0-100 to 0.75-1.25 range

    ctx.scale(baseScale * fitScale * sizeScale, baseScale * sizeScale)

    // Draw clothing image centered
    ctx.drawImage(
      clothingImg,
      -clothingImg.width / 2,
      -clothingImg.height / 3, // Position so top aligns near shoulders
      clothingImg.width,
      clothingImg.height,
    )

    ctx.restore()
  }

  // Take a snapshot
  const takeSnapshot = () => {
    if (!canvasRef.current || !videoRef.current) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    if (cameraActive) {
      // Draw the current video frame
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height)

      // Draw clothing overlay
      if (clothingImage) {
        drawClothing(ctx, clothingImage, canvas.width, canvas.height)
      }

      setHasSnapshot(true)
    }
  }

  // Reset snapshot
  const resetSnapshot = () => {
    setHasSnapshot(false)
  }

  // Save canvas as image
  const saveImage = () => {
    if (!canvasRef.current) return

    const canvas = canvasRef.current
    const image = canvas.toDataURL("image/png")

    const link = document.createElement("a")
    link.href = image
    link.download = `mirror-match-${clothingItem?.name || "try-on"}.png`
    link.click()
  }

  return (
    <div className="relative overflow-hidden rounded-xl bg-black/30 backdrop-blur-sm border border-white/20">
      <div className="aspect-[3/4] relative">
        {/* Video element (hidden unless active) */}
        {cameraActive && (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className={cn("absolute inset-0 w-full h-full object-cover", hasSnapshot ? "hidden" : "block")}
          />
        )}

        {/* Canvas for rendering */}
        <canvas ref={canvasRef} className="absolute inset-0 w-full h-full object-cover" width={600} height={800} />

        {/* Clothing info overlay */}
        <div className="absolute top-4 left-4 right-4 p-3 bg-black/40 backdrop-blur-sm rounded-lg text-white flex items-center justify-between">
          <div className="flex items-center">
            <div className="w-12 h-12 rounded bg-white/10 flex items-center justify-center mr-3 overflow-hidden">
              {clothingItem?.image && (
                <img
                  src={clothingItem.image || "/placeholder.svg"}
                  alt={clothingItem.name}
                  className="w-full h-full object-contain"
                />
              )}
            </div>
            <div>
              <h3 className="font-medium text-sm">{clothingItem?.name || "Clothing Item"}</h3>
              <p className="text-xs text-gray-300">
                {clothingItem?.brand || "Brand"} - Size {size?.toUpperCase()}
              </p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={onExit} className="text-white hover:bg-white/10">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back
          </Button>
        </div>

        {/* Controls overlay */}
        <div className="absolute bottom-0 inset-x-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
          <div className="space-y-4">
            {/* Mode selector */}
            <div className="flex justify-center mb-2">
              <Tabs
                defaultValue="silhouette"
                value={usingSilhouette ? "silhouette" : "camera"}
                onValueChange={(value) => {
                  setUsingSilhouette(value === "silhouette")
                  setCameraActive(value === "camera")
                  setHasSnapshot(false)
                }}
                className="bg-black/30 rounded-full p-1"
              >
                <TabsList className="grid grid-cols-2 w-64">
                  <TabsTrigger value="silhouette" className="rounded-full data-[state=active]:bg-pink-600">
                    Silhouette
                  </TabsTrigger>
                  <TabsTrigger value="camera" className="rounded-full data-[state=active]:bg-pink-600">
                    Camera
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </div>

            {/* Camera controls */}
            {!usingSilhouette && (
              <div className="flex justify-center gap-2">
                {!hasSnapshot ? (
                  <Button onClick={takeSnapshot} className="bg-pink-600 hover:bg-pink-700">
                    <Camera className="mr-2 h-4 w-4" />
                    Take Photo
                  </Button>
                ) : (
                  <>
                    <Button
                      onClick={resetSnapshot}
                      variant="outline"
                      className="border-white/20 text-white hover:bg-white/10"
                    >
                      <RotateCcw className="mr-2 h-4 w-4" />
                      Retake
                    </Button>
                    <Button onClick={saveImage} className="bg-pink-600 hover:bg-pink-700">
                      <Download className="mr-2 h-4 w-4" />
                      Save Image
                    </Button>
                  </>
                )}
              </div>
            )}

            {/* Adjustment controls */}
            {!hasSnapshot && (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="text-xs text-gray-300 mb-1">Position</p>
                  <Slider
                    value={[clothingPosition]}
                    min={0}
                    max={100}
                    step={1}
                    onValueChange={(value) => setClothingPosition(value[0])}
                    className="h-2"
                  />
                </div>
                <div>
                  <p className="text-xs text-gray-300 mb-1">Size</p>
                  <Slider
                    value={[clothingSize]}
                    min={75}
                    max={125}
                    step={1}
                    onValueChange={(value) => setClothingSize(value[0])}
                    className="h-2"
                  />
                </div>
                <div>
                  <p className="text-xs text-gray-300 mb-1">Fit</p>
                  <Slider
                    value={[clothingFit]}
                    min={0}
                    max={100}
                    step={1}
                    onValueChange={(value) => setClothingFit(value[0])}
                    className="h-2"
                  />
                </div>
                <div>
                  <p className="text-xs text-gray-300 mb-1">Rotation</p>
                  <Slider
                    value={[rotation]}
                    min={0}
                    max={100}
                    step={1}
                    onValueChange={(value) => setRotation(value[0])}
                    className="h-2"
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

