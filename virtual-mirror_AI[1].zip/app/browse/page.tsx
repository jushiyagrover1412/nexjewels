"use client"

import { useState } from "react"
import Link from "next/link"
import { Filter, Search, Heart, ShoppingBag, X } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger, SheetClose } from "@/components/ui/sheet"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { ProductCard } from "@/components/product-card"
import { getProducts } from "@/lib/products"

export default function BrowsePage() {
  const [filters, setFilters] = useState({
    category: "all",
    priceRange: [0, 5000],
    bodyShape: "",
    size: "",
    brand: [],
    sort: "recommended",
  })
  const [searchQuery, setSearchQuery] = useState("")
  const [activeFilters, setActiveFilters] = useState<string[]>([])

  const products = getProducts(filters, searchQuery)

  const handleFilterChange = (key: string, value: any) => {
    setFilters((prev) => ({
      ...prev,
      [key]: value,
    }))

    // Update active filters for display
    if (key === "category" && value !== "all") {
      if (!activeFilters.includes(value)) {
        setActiveFilters((prev) => [...prev, value])
      }
    } else if (key === "bodyShape" && value) {
      const formattedValue = `Body: ${value.replace("-", " ")}`
      if (!activeFilters.includes(formattedValue)) {
        setActiveFilters((prev) => [...prev.filter((f) => !f.startsWith("Body:")), formattedValue])
      }
    } else if (key === "size" && value) {
      const formattedValue = `Size: ${value.toUpperCase()}`
      if (!activeFilters.includes(formattedValue)) {
        setActiveFilters((prev) => [...prev.filter((f) => !f.startsWith("Size:")), formattedValue])
      }
    }
  }

  const removeFilter = (filter: string) => {
    setActiveFilters((prev) => prev.filter((f) => f !== filter))

    if (filter.startsWith("Body:")) {
      setFilters((prev) => ({ ...prev, bodyShape: "" }))
    } else if (filter.startsWith("Size:")) {
      setFilters((prev) => ({ ...prev, size: "" }))
    } else {
      // For category filters
      setFilters((prev) => ({ ...prev, category: "all" }))
    }
  }

  const clearAllFilters = () => {
    setFilters({
      category: "all",
      priceRange: [0, 5000],
      bodyShape: "",
      size: "",
      brand: [],
      sort: "recommended",
    })
    setActiveFilters([])
    setSearchQuery("")
  }

  return (
    <div className="min-h-screen bg-white">
      <header className="px-4 lg:px-6 h-16 flex items-center border-b sticky top-0 z-50 bg-white/80 backdrop-blur-sm">
        <Link href="/" className="flex items-center justify-center">
          <span className="font-bold text-xl bg-gradient-to-r from-pink-500 to-purple-600 text-transparent bg-clip-text">
            MirrorMatch
          </span>
        </Link>
        <div className="hidden md:flex mx-auto max-w-md w-full relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Search for products, brands and more"
            className="pl-10 border-gray-300 focus:border-pink-500 focus:ring-pink-500"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <nav className="ml-auto flex gap-4 items-center">
          <Link href="/mirror" className="text-sm font-medium hover:text-pink-600 transition-colors">
            Virtual Mirror
          </Link>
          <Button variant="ghost" size="icon">
            <Heart className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon">
            <ShoppingBag className="h-5 w-5" />
          </Button>
        </nav>
      </header>

      <div className="md:hidden px-4 py-3 border-b">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Search products"
            className="pl-10 border-gray-300"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <h1 className="text-2xl font-bold">Browse Collection</h1>

          <div className="flex items-center gap-2">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <Filter className="h-4 w-4" />
                  Filters
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-full sm:max-w-md">
                <SheetHeader>
                  <SheetTitle>Filters</SheetTitle>
                </SheetHeader>
                <div className="py-4 space-y-6">
                  <div>
                    <h3 className="font-medium mb-3">Categories</h3>
                    <div className="space-y-2">
                      {["all", "tops", "bottoms", "dresses", "outerwear", "activewear"].map((category) => (
                        <div key={category} className="flex items-center">
                          <Checkbox
                            id={`category-${category}`}
                            checked={filters.category === category}
                            onCheckedChange={() => handleFilterChange("category", category)}
                          />
                          <label htmlFor={`category-${category}`} className="ml-2 text-sm capitalize">
                            {category === "all" ? "All Categories" : category}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="font-medium mb-3">Price Range</h3>
                    <div className="px-2">
                      <Slider
                        defaultValue={[0, 5000]}
                        max={5000}
                        step={100}
                        onValueChange={(value) => handleFilterChange("priceRange", value)}
                      />
                      <div className="flex justify-between mt-2 text-sm text-gray-500">
                        <span>₹{filters.priceRange[0]}</span>
                        <span>₹{filters.priceRange[1]}</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-medium mb-3">Body Shape</h3>
                    <Select value={filters.bodyShape} onValueChange={(value) => handleFilterChange("bodyShape", value)}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select body shape" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="any">Any</SelectItem>
                        <SelectItem value="hourglass">Hourglass</SelectItem>
                        <SelectItem value="pear">Pear</SelectItem>
                        <SelectItem value="apple">Apple</SelectItem>
                        <SelectItem value="rectangle">Rectangle</SelectItem>
                        <SelectItem value="inverted-triangle">Inverted Triangle</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <h3 className="font-medium mb-3">Size</h3>
                    <div className="grid grid-cols-3 gap-2">
                      {["xs", "s", "m", "l", "xl", "xxl"].map((size) => (
                        <Button
                          key={size}
                          variant={filters.size === size ? "default" : "outline"}
                          className={`text-sm ${filters.size === size ? "bg-pink-600 hover:bg-pink-700" : ""}`}
                          onClick={() => handleFilterChange("size", size)}
                        >
                          {size.toUpperCase()}
                        </Button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="font-medium mb-3">Brands</h3>
                    <div className="space-y-2">
                      {["Myntra Luxe", "H&M", "Zara", "Forever 21", "Levis"].map((brand) => (
                        <div key={brand} className="flex items-center">
                          <Checkbox
                            id={`brand-${brand}`}
                            checked={filters.brand.includes(brand)}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                handleFilterChange("brand", [...filters.brand, brand])
                              } else {
                                handleFilterChange(
                                  "brand",
                                  filters.brand.filter((b) => b !== brand),
                                )
                              }
                            }}
                          />
                          <label htmlFor={`brand-${brand}`} className="ml-2 text-sm">
                            {brand}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex gap-2 mt-4">
                  <Button variant="outline" className="flex-1" onClick={clearAllFilters}>
                    Clear All
                  </Button>
                  <SheetClose asChild>
                    <Button className="flex-1 bg-pink-600 hover:bg-pink-700">Apply Filters</Button>
                  </SheetClose>
                </div>
              </SheetContent>
            </Sheet>

            <Select value={filters.sort} onValueChange={(value) => handleFilterChange("sort", value)}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="recommended">Recommended</SelectItem>
                <SelectItem value="price-low-high">Price: Low to High</SelectItem>
                <SelectItem value="price-high-low">Price: High to Low</SelectItem>
                <SelectItem value="newest">Newest First</SelectItem>
                <SelectItem value="popularity">Popularity</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {activeFilters.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-6">
            {activeFilters.map((filter) => (
              <Badge key={filter} variant="outline" className="flex items-center gap-1 px-3 py-1">
                {filter}
                <button onClick={() => removeFilter(filter)}>
                  <X className="h-3 w-3 ml-1" />
                </button>
              </Badge>
            ))}
            <Button variant="ghost" size="sm" onClick={clearAllFilters} className="text-xs">
              Clear All
            </Button>
          </div>
        )}

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        {products.length === 0 && (
          <div className="text-center py-12">
            <div className="mx-auto w-24 h-24 rounded-full bg-gray-100 flex items-center justify-center mb-4">
              <Search className="h-10 w-10 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium mb-2">No products found</h3>
            <p className="text-gray-500 mb-6">Try adjusting your filters or search query</p>
            <Button onClick={clearAllFilters}>Clear All Filters</Button>
          </div>
        )}
      </div>
    </div>
  )
}

