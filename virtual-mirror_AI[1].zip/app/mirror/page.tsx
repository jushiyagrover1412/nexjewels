"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, RefreshCw, Check, ChevronRight, Camera, Shirt } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BodyShapeSelector } from "@/components/body-shape-selector"
import { ClothingRecommendations } from "@/components/clothing-recommendations"
import { SizeSelector } from "@/components/size-selector"
import { Progress } from "@/components/ui/progress"
import { AIBodyScanner, type BodyMeasurements } from "@/components/ai-body-scanner"
import { VirtualTryOn } from "@/components/virtual-try-on"

export default function MirrorPage() {
  const [bodyShape, setBodyShape] = useState("")
  const [size, setSize] = useState("")
  const [step, setStep] = useState(1)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [progress, setProgress] = useState(0)
  const [scannerMode, setScannerMode] = useState(false)
  const [tryOnMode, setTryOnMode] = useState(false)
  const [measurements, setMeasurements] = useState<BodyMeasurements | null>(null)
  const [selectedClothing, setSelectedClothing] = useState<string | null>(null)

  const handleBodyShapeSelect = (shape: string) => {
    setBodyShape(shape)
  }

  const handleSizeSelect = (selectedSize: string) => {
    setSize(selectedSize)
  }

  const handleScanComplete = (detectedShape: string, bodyMeasurements: BodyMeasurements) => {
    setBodyShape(detectedShape)
    setSize(bodyMeasurements.size)
    setMeasurements(bodyMeasurements)
    setScannerMode(false)
    // Auto-advance to recommendations
    setStep(3)
  }

  const handleAnalyze = () => {
    setIsAnalyzing(true)
    // Simulate analysis process with progress
    setProgress(0)
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsAnalyzing(false)
          setStep(3)
          return 100
        }
        return prev + 5
      })
    }, 100)
  }

  const resetSelections = () => {
    setBodyShape("")
    setSize("")
    setStep(1)
    setProgress(0)
    setScannerMode(false)
    setTryOnMode(false)
    setMeasurements(null)
    setSelectedClothing(null)
  }

  const selectClothingForTryOn = (clothingId: string) => {
    setSelectedClothing(clothingId)
    setTryOnMode(true)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-purple-900">
      <header className="px-4 lg:px-6 h-16 flex items-center border-b border-white/10 sticky top-0 z-50 bg-purple-900/80 backdrop-blur-sm">
        <Button variant="ghost" size="sm" asChild className="mr-4 text-white hover:bg-white/10">
          <Link href="/">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>
        </Button>
        <h1 className="text-xl font-bold text-white">Virtual Mirror</h1>
        <div className="ml-auto flex items-center gap-4">
          <Link href="/browse" className="text-sm font-medium text-white hover:text-pink-300 transition-colors">
            Browse Collection
          </Link>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <div className="flex justify-between items-center mb-2">
              <h2 className="text-lg font-medium text-white">Your Progress</h2>
              <span className="text-sm text-gray-300">Step {step} of 3</span>
            </div>
            <Progress value={step === 1 ? 33 : step === 2 ? 66 : 100} className="h-2 bg-gray-700" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              {tryOnMode ? (
                <VirtualTryOn
                  clothingId={selectedClothing || ""}
                  bodyShape={bodyShape}
                  measurements={measurements}
                  onExit={() => setTryOnMode(false)}
                />
              ) : scannerMode ? (
                <AIBodyScanner onScanComplete={handleScanComplete} onCancel={() => setScannerMode(false)} />
              ) : (
                <Card className="w-full aspect-[3/4] flex items-center justify-center overflow-hidden bg-black/20 backdrop-blur-sm rounded-2xl border border-white/10">
                  {step === 3 ? (
                    <div className="relative w-full h-full">
                      <Image
                        src="/placeholder.svg?height=800&width=600"
                        alt="Virtual mirror"
                        fill
                        className="object-cover opacity-90"
                      />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="bg-white/90 backdrop-blur-sm p-6 rounded-xl shadow-lg max-w-xs">
                          <div className="flex items-center justify-center w-12 h-12 rounded-full bg-green-100 text-green-600 mb-4 mx-auto">
                            <Check className="h-6 w-6" />
                          </div>
                          <h3 className="text-xl font-bold text-center mb-2">Perfect Match!</h3>
                          <p className="text-center text-gray-600 mb-4">
                            We've analyzed your body shape and size to find your perfect style matches.
                          </p>
                          <div className="grid grid-cols-2 gap-2 mb-4">
                            <div className="bg-gray-100 p-2 rounded-lg">
                              <p className="text-xs text-gray-500">Body Shape</p>
                              <p className="font-semibold capitalize">{bodyShape.replace("-", " ")}</p>
                            </div>
                            <div className="bg-gray-100 p-2 rounded-lg">
                              <p className="text-xs text-gray-500">Size</p>
                              <p className="font-semibold uppercase">{size}</p>
                            </div>
                          </div>
                          {measurements && (
                            <div className="grid grid-cols-2 gap-2 mb-4 text-sm">
                              <div className="bg-gray-100 p-2 rounded">
                                <p className="text-xs text-gray-500">Bust/Chest</p>
                                <p>{Math.round(measurements.bust)}cm</p>
                              </div>
                              <div className="bg-gray-100 p-2 rounded">
                                <p className="text-xs text-gray-500">Waist</p>
                                <p>{Math.round(measurements.waist)}cm</p>
                              </div>
                            </div>
                          )}
                          <Button className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white border-0">
                            <Link href="/browse" className="flex items-center justify-center w-full">
                              Browse Recommendations <ChevronRight className="ml-1 h-4 w-4" />
                            </Link>
                          </Button>
                        </div>
                      </div>
                    </div>
                  ) : isAnalyzing ? (
                    <div className="text-center p-8 text-white">
                      <div className="w-24 h-24 border-4 border-t-transparent border-white rounded-full animate-spin mx-auto mb-6"></div>
                      <h3 className="text-2xl font-bold mb-2">Analyzing Your Profile</h3>
                      <p className="text-gray-300 mb-4">Finding the perfect styles for your body shape...</p>
                      <Progress value={progress} className="h-2 w-64 mx-auto bg-gray-700" />
                      <p className="mt-2 text-sm text-gray-300">{progress}% Complete</p>
                    </div>
                  ) : (
                    <div className="text-center p-8 text-white">
                      <Image
                        src="/placeholder.svg?height=400&width=300"
                        alt="Silhouette placeholder"
                        width={300}
                        height={400}
                        className="mx-auto mb-6 rounded-xl"
                      />
                      <h3 className="text-2xl font-bold mb-2">
                        {step === 1 ? "Let's Find Your Style" : "Almost There!"}
                      </h3>
                      <p className="text-gray-300">
                        {step === 1 ? "Select your body shape to continue" : "Select your size to continue"}
                      </p>
                    </div>
                  )}
                </Card>
              )}

              {step === 3 && !scannerMode && !tryOnMode && (
                <div className="mt-6 flex justify-center gap-3">
                  <Button onClick={resetSelections} variant="outline" className="border-pink-200 hover:bg-pink-50">
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Start Over
                  </Button>
                  <Button onClick={() => setTryOnMode(true)} className="bg-pink-600 hover:bg-pink-700">
                    <Shirt className="mr-2 h-4 w-4" />
                    Try On Clothes
                  </Button>
                </div>
              )}
            </div>

            <div>
              {step === 1 && !scannerMode && (
                <Card className="border-0 shadow-lg rounded-xl overflow-hidden">
                  <div className="bg-gradient-to-r from-pink-500 to-purple-600 p-4">
                    <h2 className="text-xl font-semibold text-white">Step 1: Body Shape</h2>
                  </div>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-center mb-6">
                      <p className="text-gray-500">Select your body shape:</p>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setScannerMode(true)}
                        className="border-pink-200 hover:bg-pink-50 text-pink-600"
                      >
                        <Camera className="mr-2 h-4 w-4" />
                        AI Scan
                      </Button>
                    </div>
                    <BodyShapeSelector onSelect={handleBodyShapeSelect} selected={bodyShape} />
                    <Button
                      className="w-full mt-6 bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white border-0"
                      disabled={!bodyShape}
                      onClick={() => setStep(2)}
                    >
                      Continue <ChevronRight className="ml-1 h-4 w-4" />
                    </Button>
                  </CardContent>
                </Card>
              )}

              {step === 2 && (
                <Card className="border-0 shadow-lg rounded-xl overflow-hidden">
                  <div className="bg-gradient-to-r from-pink-500 to-purple-600 p-4">
                    <h2 className="text-xl font-semibold text-white">Step 2: Your Size</h2>
                  </div>
                  <CardContent className="pt-6">
                    <p className="text-gray-500 mb-6">Select your clothing size:</p>
                    <SizeSelector onSelect={handleSizeSelect} selected={size} />
                    <div className="flex gap-2 mt-6">
                      <Button variant="outline" onClick={() => setStep(1)} className="border-pink-200 hover:bg-pink-50">
                        Back
                      </Button>
                      <Button
                        className="flex-1 bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white border-0"
                        disabled={!size}
                        onClick={handleAnalyze}
                      >
                        {isAnalyzing ? (
                          <>
                            <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                            Analyzing...
                          </>
                        ) : (
                          <>Get Recommendations</>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              {step === 3 && (
                <Card className="border-0 shadow-lg rounded-xl overflow-hidden">
                  <div className="bg-gradient-to-r from-pink-500 to-purple-600 p-4">
                    <h2 className="text-xl font-semibold text-white">Your Recommendations</h2>
                  </div>
                  <CardContent className="pt-6">
                    <p className="text-gray-500 mb-4">
                      Based on your {bodyShape.replace("-", " ")} body shape and size {size.toUpperCase()}, we
                      recommend:
                    </p>
                    <Tabs defaultValue="tops" className="w-full">
                      <TabsList className="w-full mb-4">
                        <TabsTrigger value="tops" className="flex-1">
                          Tops
                        </TabsTrigger>
                        <TabsTrigger value="bottoms" className="flex-1">
                          Bottoms
                        </TabsTrigger>
                        <TabsTrigger value="dresses" className="flex-1">
                          Dresses
                        </TabsTrigger>
                      </TabsList>
                      <TabsContent value="tops">
                        <ClothingRecommendations
                          type="tops"
                          bodyShape={bodyShape}
                          size={size}
                          onTryOn={selectClothingForTryOn}
                        />
                      </TabsContent>
                      <TabsContent value="bottoms">
                        <ClothingRecommendations
                          type="bottoms"
                          bodyShape={bodyShape}
                          size={size}
                          onTryOn={selectClothingForTryOn}
                        />
                      </TabsContent>
                      <TabsContent value="dresses">
                        <ClothingRecommendations
                          type="dresses"
                          bodyShape={bodyShape}
                          size={size}
                          onTryOn={selectClothingForTryOn}
                        />
                      </TabsContent>
                    </Tabs>
                    <div className="mt-6">
                      <Button className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white border-0">
                        <Link href="/browse" className="flex items-center justify-center w-full">
                          See All Recommendations
                        </Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

