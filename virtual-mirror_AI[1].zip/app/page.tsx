import Link from "next/link"
import Image from "next/image"
import { ArrowRight, ShoppingBag } from "lucide-react"

import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-white to-gray-50">
      <header className="px-4 lg:px-6 h-16 flex items-center border-b sticky top-0 z-50 bg-white/80 backdrop-blur-sm">
        <Link href="/" className="flex items-center justify-center">
          <span className="font-bold text-xl bg-gradient-to-r from-pink-500 to-purple-600 text-transparent bg-clip-text">
            MirrorMatch
          </span>
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link href="#" className="text-sm font-medium hover:text-pink-600 transition-colors">
            About
          </Link>
          <Link href="#" className="text-sm font-medium hover:text-pink-600 transition-colors">
            Features
          </Link>
          <Link href="/browse" className="text-sm font-medium hover:text-pink-600 transition-colors">
            Browse
          </Link>
          <Link href="#" className="text-sm font-medium hover:text-pink-600 transition-colors">
            Contact
          </Link>
        </nav>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-50 to-pink-50 opacity-50"></div>
          <div className="container px-4 md:px-6 relative">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div className="space-y-4">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl bg-gradient-to-r from-pink-600 to-purple-600 text-transparent bg-clip-text">
                  Find Your Perfect Style Match
                </h1>
                <p className="max-w-[600px] text-gray-500 md:text-xl">
                  Our virtual mirror analyzes your body shape and size to recommend clothing that fits and flatters you
                  perfectly.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button
                    size="lg"
                    className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white border-0"
                  >
                    <Link href="/mirror" className="flex items-center">
                      Try Virtual Mirror <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                  <Button size="lg" variant="outline" className="border-pink-200 hover:bg-pink-50">
                    <Link href="/browse" className="flex items-center">
                      Browse Collection <ShoppingBag className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </div>
              <div className="relative h-[400px] md:h-[500px] rounded-2xl overflow-hidden shadow-2xl transform md:translate-y-4 transition-all duration-500 hover:translate-y-0">
                <Image
                  src="/placeholder.svg?height=800&width=600"
                  alt="Virtual mirror preview"
                  fill
                  className="object-cover"
                  priority
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
                  <div className="p-6 text-white">
                    <h3 className="text-xl font-bold">Personalized Style</h3>
                    <p className="text-sm opacity-80">Recommendations tailored to your unique body shape</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 bg-white">
          <div className="container px-4 md:px-6">
            <div className="text-center mb-10">
              <h2 className="text-3xl font-bold">How It Works</h2>
              <p className="text-gray-500 mt-2">Three simple steps to find your perfect style</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="flex flex-col items-center text-center p-6 rounded-xl bg-gradient-to-br from-pink-50 to-purple-50 border border-pink-100">
                <div className="w-16 h-16 rounded-full bg-gradient-to-r from-pink-500 to-purple-600 flex items-center justify-center text-white font-bold text-xl mb-4">
                  1
                </div>
                <h3 className="text-xl font-semibold mb-2">Select Your Body Shape</h3>
                <p className="text-gray-500">Choose from different body shapes to get personalized recommendations.</p>
              </div>
              <div className="flex flex-col items-center text-center p-6 rounded-xl bg-gradient-to-br from-pink-50 to-purple-50 border border-pink-100">
                <div className="w-16 h-16 rounded-full bg-gradient-to-r from-pink-500 to-purple-600 flex items-center justify-center text-white font-bold text-xl mb-4">
                  2
                </div>
                <h3 className="text-xl font-semibold mb-2">Enter Your Size</h3>
                <p className="text-gray-500">Provide your size information for accurate clothing suggestions.</p>
              </div>
              <div className="flex flex-col items-center text-center p-6 rounded-xl bg-gradient-to-br from-pink-50 to-purple-50 border border-pink-100">
                <div className="w-16 h-16 rounded-full bg-gradient-to-r from-pink-500 to-purple-600 flex items-center justify-center text-white font-bold text-xl mb-4">
                  3
                </div>
                <h3 className="text-xl font-semibold mb-2">Get Recommendations</h3>
                <p className="text-gray-500">Browse personalized clothing recommendations that flatter your figure.</p>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="bg-gradient-to-r from-purple-900 to-pink-900 text-white py-12">
        <div className="container px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-bold text-xl mb-4">MirrorMatch</h3>
              <p className="text-sm text-gray-300">Find clothing that fits and flatters your unique body shape.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>
                  <Link href="/" className="hover:text-white">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="/mirror" className="hover:text-white">
                    Virtual Mirror
                  </Link>
                </li>
                <li>
                  <Link href="/browse" className="hover:text-white">
                    Browse Collection
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>
                  <Link href="#" className="hover:text-white">
                    Help Center
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white">
                    Size Guide
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white">
                    Contact Us
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Stay Updated</h4>
              <p className="text-sm text-gray-300 mb-2">Subscribe to our newsletter</p>
              <div className="flex">
                <input
                  type="email"
                  placeholder="Your email"
                  className="px-3 py-2 text-black text-sm rounded-l-md w-full"
                />
                <Button className="rounded-l-none bg-pink-600 hover:bg-pink-700">Subscribe</Button>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-xs text-gray-400">© 2024 MirrorMatch. All rights reserved.</p>
            <div className="flex gap-4 mt-4 md:mt-0">
              <Link href="#" className="text-xs text-gray-400 hover:text-white">
                Terms
              </Link>
              <Link href="#" className="text-xs text-gray-400 hover:text-white">
                Privacy
              </Link>
              <Link href="#" className="text-xs text-gray-400 hover:text-white">
                Cookies
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

